/*************  ✨ Codeium Command ⭐  *************/
export interface Product {
    id: number;
    name: string;
    price: number;
    description: string;
    stock: number;
    createdAt: Date;
    updatedAt: Date;
}
/******  988f4cf1-f161-49d0-a67c-6dc7b1537f77  *******/ 