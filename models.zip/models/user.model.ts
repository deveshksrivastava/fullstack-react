/*************  ✨ Codeium Command ⭐  *************/
export interface User {
    id: number;
    name: string;
    email: string;
    password: string;
    role: 'USER' | 'ADMIN';
    createdAt: Date;
    updatedAt: Date;
}
/******  21095e25-1391-474c-baa4-e0b85c08ddf8  *******/ 