import express, { Express, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import { DefaultAzureCredential } from '@azure/identity';
import { SecretClient } from '@azure/keyvault-secrets';
import mssql from 'mssql';
import routerv1 from '../routers/v1';
import routerv2 from '../routers/v2';
import dotenv, { config } from 'dotenv';
import logger from './logger';
import morgan from "morgan";
import { errorMiddleware } from '../middleware/error';

const morganFormat = ":method :url :status :response-time ms"


const app = express();
app.use(cors()); //cors middle ware 1, execure in order
app.use(express.json()); //express middle ware 2

const options = {
  dotfiles: 'ignore',
  etag: false,
  extensions: ['htm', 'html'],
  index: false,
  maxAge: '1d',
  redirect: false,
  setHeaders(res: Response, path: string, stat: any) {
    res.set('Accept', 'application/json')
    res.set('x-timestamp', Date.now().toString())
  }
}

app.use(express.static('public', options))

// morgan middleware: execure in order, log every request, log every response, log every error, log every warning
app.use(
  morgan(morganFormat, {
    stream: {
      write: (message) => {
        const logObject = {
          method: message.split(" ")[0],
          url: message.split(" ")[1],
          status: message.split(" ")[2],
          responseTime: message.split(" ")[3],
        };
        logger.info(JSON.stringify(logObject));
      },
    },
  })
);

dotenv.config();

const port = process.env.PORT || 5001; // Use environment variable for port or default to 3000

// Example API endpoint (replace with your actual logic)
app.get('/host', (req: Request, res: Response) => {
  const data = { message: 'Hello from the API!' };
  res.json(data);
});

app.use('/api', routerv1);
app.use('/api', routerv2); //localhost:5001/api/v2/home

app.use(errorMiddleware);

// // Local Middleware to simulate an error
// app.get('/error', (req: Request, res: Response) => {
//   logger.info("This is an info message");
//   logger.error("This is an error message");
//   logger.warn("This is a warning message");
//   logger.debug("This is a debug message");
//   throw new Error('This is a simulated error!');
// });

// // Global error handling middleware
// app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
//   console.log('Global error handling middleware', err);
//   logger.error(err.message); // Log the error message
//   res.status(500).json({ error: 'Internal Server Error', message: err.message });
// });

// 404 Not Found middleware
app.use((req: Request, res: Response) => {
  res.status(404).json({ error: 'Not Found', message: 'The requested resource could not be found.' });
});


// Start the servers
app.listen(port, () => {
  // http://localhost:5001/api/data
  console.log(`Server listening on http://${process.env.HOST}:${port}`);
});
