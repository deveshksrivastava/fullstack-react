// message, status code, error code,error message

export class HttpException extends Error {
    message: string;
    statusCode: number;
    errorCode: ErrorCodes;
    errorMessage: any;

    constructor(message: string, statusCode: number, errorCode: ErrorCodes, errorMessage: any) {
        console.log('get message1:', message);
        console.log('get errorMessage1:', errorMessage);
        console.log('get errorCode1:', errorCode);
        super(message);
        this.message = message;
        this.statusCode = statusCode;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }
}

export enum ErrorCodes {
    USER_NOT_FOUND = 1001,
    USER_ALREADY_EXISTS = 1002,
    INCORRECT_PASSWORD = 1003,
    UNPROCESSABLE_ENTITY = 2001,
    INTERNAL_EXCEPTION = 3001
}