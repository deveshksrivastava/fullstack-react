import { ErrorCodes, HttpException } from "./root";

export class BadRequest extends HttpException {
    constructor(message: string, errorCode: ErrorCodes) {
        console.log('get message:', message);
        super(message, 400, errorCode, 'null');
    }
}

// class BadRequest extends Error {
//     statusCode: string;
//     errorMessage: string;
//     constructor(message: string) {
//         const errorMessage = `Bad Request is comming: ${message}`
//         super(message);
//         this.statusCode = "400";
//         this.errorMessage = errorMessage;
//     }
// }

// module.exports = BadRequest;