import { NextFunction, Request, Response } from "express";
import { z } from "zod";

const createProductSchema = z.object({
    name: z.string().min(3),
    price: z.number().positive(),
    description: z.string().min(10),
    stock: z.number().positive(),
});

const createProductValidation = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {
        console.log('createProductValidation')
        const result = createProductSchema.parse(req.body);
        req.body = result;
        next();
    } catch (error: any) {
        return res.status(400).json({ message: error.message });
    }
};

export {
    createProductValidation,
    // deleteUser
};