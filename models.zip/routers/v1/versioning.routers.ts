import { Router, Request, Response, NextFunction } from 'express';
import logger from '../../src/logger';

// create test case for this

const router = Router();


// For version 1: GET http://localhost:3000/api/v1/resource
// For version 2: GET http://localhost:3000/api/v2/resource

// Version 1 of the API
router.get('/api/v1/resource', (req, res) => {
    throw new Error('This is a simulated error! Api is not working as per expected');
    res.json({ message: 'This is version 1 of the resource.' });
});

// router.use((err: Error, req: Request, res: Response, next: NextFunction) => {
//     logger.error(err.message); // Log the error message
//     res.status(500).json({ error: 'Internal Server Error', message: err.message });
// });

// Version 2 of the API
router.get('/api/v2/resource', (req, res) => {
    res.json({ message: 'This is version 2 of the resource with additional features.' });
});


// Query parameters versioning
// For version 1:              GET http://localhost:3000/api/resource?version=1
// For version 2:              GET http://localhost:3000/api/resource?version=2
// For an invalid version:     GET http://localhost:3000/api/resource?version=3
router.get('/api/resource', (req, res) => {
    const version = req.query.version;
    if (version === '1') {
        res.json({ message: 'This is version 1 of the resource.' });
    } else if (version === '2') {
        res.json({ message: 'This is version 2 of the resource with additional features.' });
    } else {
        res.status(400).json({ error: 'Invalid version specified.' });
    }
});

// Custome Header Version are included in the http headers of the api request
// Middleware to handle versioning based on custom header
//GET http://localhost:3000/api/resource
// Headers: 
// {
//     "api-version": "2"
// }
// Middleware to handle custom header versioning
router.get('/api/resource', (req: Request, res: Response) => {
    const version = req.headers['x-api-version']; // Custom header to specify version

    if (version === '1.0') {
        return res.json({ message: 'This is version 1.0 of the resource.' });
    } else if (version === '2.0') {
        return res.json({ message: 'This is version 2.0 of the resource with additional features.' });
    } else {
        return res.status(400).json({ error: 'Bad Request: Please specify a valid version in the X-API-Version header.' });
    }
});
// Implementing Content Negotiation Versioning in Node.js with TypeScript
// Middleware to handle content negotiation
// For version 1:
// GET http://localhost:3000/api/resource
// Headers: 
// {
//     "Accept": "application/vnd.example.v1+json"
// }

// For version 2:
// GET http://localhost:3000/api/resource
// Headers: 
// {
//     "Accept": "application/vnd.example.v2+json"
// }

// For an invalid version:
// GET http://localhost:3000/api/resource
// Headers: 
// {
//     "Accept": "application/vnd.example.v3+json"
// }
router.get('/api/resource', (req: Request, res: Response) => {
    const acceptHeader = req.headers['accept'];

    if (acceptHeader?.includes('application/vnd.example.v2+json')) {
        return res.json({ message: 'This is version 2 of the resource with additional features.' });
    } else if (acceptHeader?.includes('application/vnd.example.v1+json')) {
        return res.json({ message: 'This is version 1 of the resource.' });
    } else {
        return res.status(406).json({ error: 'Not Acceptable: Please specify a valid version in the Accept header.' });
    }
});



export default router;