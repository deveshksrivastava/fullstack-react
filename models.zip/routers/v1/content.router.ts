import { Router, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';

// create test case for this

const router = Router();

router.get('/data.json', async (req: Request, res: Response) => {
  const filePath = path.join(__dirname, '../public', 'data.json');
  console.log("->", filePath)
  fs.readFile(filePath, 'utf8', (err, data) => {
      if (err) {
          return res.status(500).json({ error: 'Failed to read file' });
      }
      res.json(JSON.parse(data));
  });
});

router.post('/data.json', (req: Request, res: Response) => {
  const updatedContent = req.body;
  console.log("->",updatedContent)
  fs.writeFileSync('./public/data.json', JSON.stringify(updatedContent, null, 2));
  res.json(updatedContent);
});

export default router;
