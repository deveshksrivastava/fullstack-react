import { Router, Request, Response, NextFunction } from 'express';
import { nextTick } from 'process';
import { crearteUser, deleteUser } from '../../controllers/user_contoller';
import { getProducts, createProduct } from '../../controllers/products_Controller';
import { BadRequest } from "../../exceptions/bad_request";
import { ErrorCodes } from "../../exceptions/root";


// create test case for this

const router = Router();

// simple logger for this router's requests
// all requests to this router will first hit this middleware
router.use((req, res, next) => {
  console.log('%s %s %s', req.method, req.url, req.path)
  next()
})

const logger = (req: Request, res: Response, next: NextFunction) => {
  console.log('logger'); //1
  next();
  console.log('logger end');//4
};

const loggerPrint = (req: Request, res: Response, next: NextFunction) => {
  console.log('loggerPrint'); //2
  next();
  console.log('loggerPrint end'); //3
};

const createProductValidation = (req: Request, res: Response, next: NextFunction) => {
  console.log('loggerPrint'); //2
  next();
  console.log('loggerPrint end'); //3
};

// http://localhost:5001/api/v2/home
router.get('/home', logger, loggerPrint, (req: Request, res: Response) => {
  res.json({
    message: 'Hello from the API1!',
  });
});

router.get('/users', logger, loggerPrint, crearteUser);
router.get('/users/:id', logger, loggerPrint, deleteUser);

// http://localhost:5001/api/v2/error
router.get('/error', (req: Request, res: Response) => {
  // const x = new Error('This is a simulated error new error!');
  // return res.status(500).json({ error: 'Interna`l Server Error', message: x.message });
  const user = ''
  if (!user) {
    throw new BadRequest('User already exists', ErrorCodes.USER_ALREADY_EXISTS)
  }

  if (!user) {
    res.status(200).json({ success: true, error: 'Internal Server Error', message: new BadRequest('some message', ErrorCodes.UNPROCESSABLE_ENTITY) });
  }

  const x = new Error('This is a simulated error new error!');
  return res.status(500).json({ error: 'Internal Server Error', message: new BadRequest('some message', ErrorCodes.UNPROCESSABLE_ENTITY) });
});


// this will only be invoked if the path starts with /bar from the mount point
// http://localhost:5001/api/v2/bar
router.get('/bar', (req: Request, res: Response, next: NextFunction) => {
  res.send('bar');
  // next(); //// ... maybe some additional /bar logging ...
});

// always invoked
router.use((req, res, next) => {
  console.log('always invoked');
  res.send('Hello World')
})

export default router;
