import { Router, Request, Response, NextFunction } from 'express';
import { getProducts, createProduct } from '../../controllers/products_Controller';
import { createProductValidation } from '../../middleware/create_product_validation';


// create test case for this

const router = Router();
console.log('product router');

// const createProductValidation = (req: Request, res: Response, next: NextFunction) => {
//   console.log('loggerPrint'); //2
//   next();
//   console.log('loggerPrint end'); //3
// };

router.get('/products', getProducts);
// router.post('/products', createProductValidation, createProduct);


export default router;
