import { Request, Response } from "express";
import { ProductService } from "../services/product_service";

export const getProducts = async (req: Request, res: Response) => {
    console.log('getProducts');
    try {
        const productService = new ProductService();
        const products = await productService.getAllProducts();
        res.status(200).json(products);
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
}

export const createProduct = async (req: Request, res: Response) => {
    try {
        const productService = new ProductService();
        const productData = req.body;
        await productService.createProduct(productData);
        res.status(201).json({ message: "Product created successfully" });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: "Internal Server Error" });
    }
}