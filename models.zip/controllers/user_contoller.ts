import { Router, Request, Response, NextFunction } from 'express';

// This file will not have the bussiness logic, all the bussiess will go to the service layer 

function crearteUser(req: Request, res: Response) {
    try {
        const { userIDs } = req.body
        console.log("start crearteUser")
        // res.status(200).json(userIDs)
        res.status(200).json({ id: 1001, displayName: 'test', userPrincipalName: 'test' })
    } catch (error) {
        console.log(error)
    }
}

function deleteUser(req: Request, res: Response) {
    try {
        const { userIDs } = req.body
        console.log("user", userIDs)
        res.status(200).json(userIDs)
    } catch (error) {
        console.log(error)
    }
}

export {
    crearteUser,
    deleteUser
};



