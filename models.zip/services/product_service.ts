/*************  ✨ Codeium Command ⭐  *************/
import { Product } from "../models/product_model";
export class ProductService {
    async createProduct(productData: {
        name: string,
        price: number,
        description: string,
        stock: number
    }): Promise<void> {
        // implement product creation logic
        // for now just log
        console.log('Creating product', productData);
    }
    async getAllProducts(): Promise<Product[]> {
        // implement get all products logic
        // for now just return an empty array
        return [{
            id: 1,
            name: 'Product 1',
            price: 10,
            description: 'Description 1',
            stock: 10,
            createdAt: new Date(),
            updatedAt: new Date()
        }];
    }
    //   
}
export const productService = new ProductService();

