// in memory DB
import { User } from "../models/user.model";

export class UserService {
    private users: User[] = []; // In-memory database

    async getAllUsers(): Promise<User[]> {
        return this.users;
    }
}
